package com.app.exceptions;

public class AdminException extends Exception {
	
	public AdminException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	public AdminException() {
		// TODO Auto-generated constructor stub
	}
	
	
	

}
