package com.app.exceptions;

public class feedbackException extends Exception {
     public feedbackException() {
		// TODO Auto-generated constructor stub
	}
     
     public feedbackException(String message) {
 		// TODO Auto-generated constructor stub
    	 super(message);
 	}
}
